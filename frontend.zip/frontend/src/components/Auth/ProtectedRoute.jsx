// import { useLocation } from "react-router-dom"

// export default function ProtectedRoute({ children, allowedRoles = [] }) {
//     // // const { isAuthenticated, user } = useAuthStore()
//     // const location = useLocation()

//     // if (!isAuthenticated) {
//     //     return <Navigate to="/login" state={{ from: location }} replace />
//     // }

//     // if (allowedRoles.length > 0 && user && !allowedRoles.includes(user.role)) {
//     //     return <UnauthorizedPage />
//     // }
//     // return children
// };